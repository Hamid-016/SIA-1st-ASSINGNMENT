/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import java.sql.*;

/**
 *
 * @author Shan Wijenayaka
 */
public class DBConnection {
    private Connection DBConnection;
    public Connection connect(){
         try {
            Class.forName("com.mysql.jdbc.Driver");
            System.out.println("Connection Success(1)");
            
        } catch (ClassNotFoundException ex) {
            System.exit(0);
            
        }
    

